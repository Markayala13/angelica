"use client"

import { motion, useInView } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"
import { useRef } from "react"

const plans = [
  {
    name: "Signature",
    tagline: "The Perfect Introduction",
    price: "From $150",
    description: "For those ready to experience the Angelica difference. Single-area treatments with our full consultation and care protocol.",
    features: [
      "Single treatment area",
      "Comprehensive skin analysis",
      "Personalized care instructions",
      "Flexible scheduling",
    ],
    popular: false,
  },
  {
    name: "Curated",
    tagline: "Our Most Requested",
    price: "From $399",
    description: "The complete transformation package. Multiple areas, priority access, and our dedicated support throughout your journey.",
    features: [
      "Multiple treatment areas",
      "Bespoke treatment protocol",
      "Priority appointment access",
      "Progress documentation",
      "Extended aftercare support",
    ],
    popular: true,
  },
  {
    name: "Bespoke",
    tagline: "The Ultimate Experience",
    price: "By Consultation",
    description: "For those who desire nothing less than comprehensive transformation. Full customization, VIP access, and dedicated concierge care.",
    features: [
      "Unlimited treatment areas",
      "Combined laser & skin therapies",
      "Same-day availability",
      "Personal care coordinator",
      "Complimentary maintenance sessions",
    ],
    popular: false,
  },
]

export function Pricing() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section ref={ref} className="py-32 lg:py-44 bg-background relative overflow-hidden">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-20 lg:mb-28"
        >
          <span className="text-[10px] tracking-[0.4em] uppercase text-muted-foreground block mb-4">
            Investment
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-medium text-foreground max-w-2xl mx-auto leading-tight mb-6">
            Tailored to <span className="italic">your vision</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Transparent pricing reflecting the quality, privacy, and personalized attention you deserve.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ 
                delay: 0.2 + index * 0.15, 
                duration: 0.9,
                ease: [0.22, 1, 0.36, 1]
              }}
              className={cn(
                "relative p-10 lg:p-12 transition-all duration-500",
                plan.popular 
                  ? "bg-foreground text-background" 
                  : "bg-card border border-border hover:border-foreground/20"
              )}
            >
              {plan.popular && (
                <div className="absolute -top-px left-0 right-0 h-px bg-accent" />
              )}

              <div className="mb-10">
                <span className={cn(
                  "text-[10px] tracking-[0.3em] uppercase mb-3 block",
                  plan.popular ? "text-background/60" : "text-muted-foreground"
                )}>
                  {plan.tagline}
                </span>
                <h3 className={cn(
                  "text-2xl font-serif font-medium mb-2",
                  plan.popular ? "text-background" : "text-foreground"
                )}>
                  {plan.name}
                </h3>
                <p className={cn(
                  "text-3xl lg:text-4xl font-serif font-light",
                  plan.popular ? "text-background" : "text-foreground"
                )}>
                  {plan.price}
                </p>
              </div>

              <p className={cn(
                "text-sm leading-relaxed mb-8",
                plan.popular ? "text-background/70" : "text-muted-foreground"
              )}>
                {plan.description}
              </p>

              <ul className="space-y-4 mb-10">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-sm">
                    <div className={cn(
                      "w-px h-4 mt-1 flex-shrink-0",
                      plan.popular ? "bg-background/40" : "bg-foreground/20"
                    )} />
                    <span className={plan.popular ? "text-background/90" : "text-muted-foreground"}>
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              <Button 
                className={cn(
                  "w-full rounded-none py-6 text-xs tracking-[0.15em] uppercase group",
                  plan.popular 
                    ? "bg-background text-foreground hover:bg-background/90" 
                    : "bg-foreground text-background hover:bg-foreground/90"
                )}
              >
                <span>Reserve Now</span>
                <ArrowRight className="ml-3 w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </motion.div>
          ))}
        </div>

        {/* Fine Print */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="text-center mt-16"
        >
          <p className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground mb-4">
            Final pricing determined during consultation based on treatment areas and protocol
          </p>
          <a 
            href="#consultation" 
            className="text-xs tracking-[0.15em] uppercase text-foreground underline underline-offset-4 hover:text-muted-foreground transition-colors"
          >
            Request Full Pricing Guide
          </a>
        </motion.div>
      </div>
    </section>
  )
}
